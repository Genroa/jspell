Les sources sont dans src.
Les dictionnaires sont dans dic.
Les manuels et la javadoc sont dans doc.
Et demain.txt et shakespeare sont deux fichiers de test qui sont "corrig�s".